<?php

// smartlist photos
td_demo_media::add_image_to_media_gallery('td_pic_s4',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/s4.jpg");
td_demo_media::add_image_to_media_gallery('td_pic_s5',                  "http://demo_content.tagdiv.com/Newspaper_6/wedding/s5.jpg");

// logos
td_demo_media::add_image_to_media_gallery('td_logo_header',             "http://demo_content.tagdiv.com/Newspaper_6/wedding/wedding-header.png");
td_demo_media::add_image_to_media_gallery('td_logo_footer',             "http://demo_content.tagdiv.com/Newspaper_6/wedding/wedding-footer.png");

// footer image
td_demo_media::add_image_to_media_gallery('td_footer_bg',               "http://demo_content.tagdiv.com/Newspaper_6/wedding/footer-image.jpg");