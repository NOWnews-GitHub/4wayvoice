<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_p3',                  "http://demo_content.tagdiv.com/Newspaper_6/default/p3.jpg");
//logo
td_demo_media::add_image_to_media_gallery('td_pic_logo',                'http://demo_content.tagdiv.com/Newspaper_6/default/logo-header.png');
td_demo_media::add_image_to_media_gallery('td_pic_logo_footer',         'http://demo_content.tagdiv.com/Newspaper_6/default/logo-white.png');
//ads
td_demo_media::add_image_to_media_gallery('td_default_ad_full',         "http://demo_content.tagdiv.com/Newspaper_6/default/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_default_ad_sidebar',      "http://demo_content.tagdiv.com/Newspaper_6/default/rec300.jpg");