<?php
/**
 * Created by ra on 6/13/2015.
 */

td_demo_media::add_image_to_media_gallery('td_pic_logo_desktop_retina', 'http://demo_content.tagdiv.com/Newspaper_6/video/video-stack-logo-retina.png');

//ads
td_demo_media::add_image_to_media_gallery('td_video_full_ad',           "http://demo_content.tagdiv.com/Newspaper_6/video/rec728.jpg");
td_demo_media::add_image_to_media_gallery('td_video_sidebar_ad',        "http://demo_content.tagdiv.com/Newspaper_6/video/rec300.jpg");

